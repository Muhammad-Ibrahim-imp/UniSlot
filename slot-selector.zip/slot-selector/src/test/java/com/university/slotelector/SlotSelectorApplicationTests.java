package com.university.slotelector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

/**
 * Basic Spring context load test.
 * Verifies that the entire application context starts without errors.
 * Run with: ./gradlew test
 */
@SpringBootTest
@ActiveProfiles("test")
class SlotSelectorApplicationTests {

    @Test
    void contextLoads() {
        // If this test passes, the entire Spring context
        // (security, JPA, services, controllers) loaded successfully.
    }
}
