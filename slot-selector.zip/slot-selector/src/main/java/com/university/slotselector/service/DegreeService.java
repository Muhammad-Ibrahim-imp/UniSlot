package com.university.slotselector.service;

import com.university.slotselector.dto.request.CreateDegreeRequest;
import com.university.slotselector.dto.request.AddCourseToDegreeRequest;
import com.university.slotselector.dto.response.DegreeResponse;

import java.util.List;

/** Contract for degree and degree-course-mapping operations. */
public interface DegreeService {
    DegreeResponse create(CreateDegreeRequest request);
    DegreeResponse getById(Long id);
    List<DegreeResponse> getByDepartment(Long departmentId);
    void addCourseToDegree(AddCourseToDegreeRequest request);
    void removeCourseFromDegree(Long degreeId, Long courseId);
    void delete(Long id);
    // edit: added update method to allow editing degree name, code and duration
    DegreeResponse update(Long id, CreateDegreeRequest request);
}
