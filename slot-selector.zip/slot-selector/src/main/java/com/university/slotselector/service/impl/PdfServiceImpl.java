package com.university.slotselector.service.impl;

import com.university.slotselector.entity.LectureSlot;
import com.university.slotselector.entity.SlotLecture;
import com.university.slotselector.entity.Student;
import com.university.slotselector.enums.LectureDay;
import com.university.slotselector.exception.ResourceNotFoundException;
import com.university.slotselector.repository.LectureSlotRepository;
import com.university.slotselector.repository.StudentRepository;
import com.university.slotselector.service.PdfService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class PdfServiceImpl implements PdfService {

    private final StudentRepository     studentRepo;
    private final LectureSlotRepository slotRepo;

    @Value("${app.pdf.output-dir}")
    private String pdfOutputDir;

    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm");

    private static final List<LectureDay> ORDERED_DAYS = List.of(
            LectureDay.MONDAY, LectureDay.TUESDAY, LectureDay.WEDNESDAY,
            LectureDay.THURSDAY, LectureDay.FRIDAY, LectureDay.SATURDAY);

    @Override
    @Transactional(readOnly = true)
    public String generateTimetablePdf(String studentEmail) {

        Student student = studentRepo.findByUserEmail(studentEmail)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Student", "email", studentEmail));

        // Each element is one enrolled LectureSlot (= one section/slot chosen by student)
        List<LectureSlot> enrolledSlots =
                slotRepo.findSlotsByStudentEnrollment(student.getId());

        if (enrolledSlots.isEmpty()) {
            throw new RuntimeException(
                "No slots enrolled yet. Please select your courses first.");
        }

        // Build grid: (day, timeKey) → cell content
        // Collect all unique time keys for row headers
        TreeSet<String> timeKeys = new TreeSet<>();
        Map<LectureDay, Map<String, String>> grid = new HashMap<>();
        for (LectureDay day : ORDERED_DAYS) grid.put(day, new HashMap<>());

        for (LectureSlot slot : enrolledSlots) {
            for (SlotLecture lec : slot.getLectures()) {
                String timeKey = lec.getStartTime().format(TIME_FMT)
                               + " – " + lec.getEndTime().format(TIME_FMT);
                timeKeys.add(timeKey);
                String cell = "<b>" + slot.getCourse().getName() + "</b><br/>"
                            + slot.getSlotName() + "<br/>"
                            + slot.getProfessor().getName() + "<br/>"
                            + (lec.getVenue() != null ? "📍 " + lec.getVenue() : "");
                grid.get(lec.getDayOfWeek()).put(timeKey, cell);
            }
        }

        long totalCredits = enrolledSlots.stream()
                .mapToInt(ls -> ls.getCourse().getCreditHours())
                .sum();

        String html = buildHtml(student, timeKeys, grid, totalCredits);

        String fileName = "timetable_"
                + student.getRollNumber().replace("/", "-") + ".pdf";
        Path outputPath = Paths.get(pdfOutputDir, fileName).toAbsolutePath().normalize();

        try (FileOutputStream fos = new FileOutputStream(outputPath.toFile())) {
            com.itextpdf.html2pdf.HtmlConverter.convertToPdf(html, fos);
        } catch (IOException e) {
            log.error("PDF generation failed for {}: {}", studentEmail, e.getMessage());
            throw new RuntimeException("PDF generation failed: " + e.getMessage());
        }

        log.info("PDF generated for {}: {}", student.getRollNumber(), outputPath);
        return outputPath.toString();
    }

    private String buildHtml(Student student,
                              TreeSet<String> timeKeys,
                              Map<LectureDay, Map<String, String>> grid,
                              long totalCredits) {
        StringBuilder sb = new StringBuilder();
        sb.append("""
            <!DOCTYPE html><html><head><meta charset="UTF-8"/>
            <style>
              body { font-family: Arial, sans-serif; font-size: 11px; margin: 20px; }
              h1   { color: #1e1b4b; font-size: 18px; }
              h3   { color: #555; margin: 4px 0; }
              .info-table { width: 100%; margin-bottom: 20px; }
              .info-table td { padding: 3px 8px; }
              .info-table .label { font-weight: bold; color: #1e1b4b; width: 160px; }
              .timetable { width: 100%; border-collapse: collapse; margin-top: 10px; }
              .timetable th { background: #1e1b4b; color: white; padding: 8px 4px;
                              text-align: center; font-size: 10px; border: 1px solid #999; }
              .timetable td { border: 1px solid #ccc; padding: 6px 4px;
                              vertical-align: top; font-size: 9px; min-width: 80px; }
              .time-col  { background: #f0f4ff; font-weight: bold; text-align: center;
                           width: 90px; white-space: nowrap; color: #1e1b4b; }
              .slot-cell { background: #ede9fe; text-align: center; }
              .empty     { background: #fafafa; }
              .footer    { margin-top: 16px; font-size: 10px; color: #888; }
            </style></head><body>
            """);

        sb.append("<h1>&#127979; University Lecture Timetable</h1>");
        sb.append("<table class='info-table'>");
        appendRow(sb, "Student Name",  student.getName());
        appendRow(sb, "Roll Number",   student.getRollNumber());
        appendRow(sb, "Department",    student.getDepartment().getName());
        appendRow(sb, "Degree",        student.getDegree().getName());
        appendRow(sb, "Semester",      student.getCurrentSemester().toString());
        appendRow(sb, "Total Credits", totalCredits + " credit hours");
        sb.append("</table><h3>Weekly Schedule</h3>");

        sb.append("<table class='timetable'><tr><th>Time</th>");
        for (LectureDay day : ORDERED_DAYS)
            sb.append("<th>").append(day.name(), 0, 3).append("</th>");
        sb.append("</tr>");

        for (String timeKey : timeKeys) {
            sb.append("<tr><td class='time-col'>").append(timeKey).append("</td>");
            for (LectureDay day : ORDERED_DAYS) {
                String cell = grid.get(day).get(timeKey);
                if (cell != null)
                    sb.append("<td class='slot-cell'>").append(cell).append("</td>");
                else
                    sb.append("<td class='empty'>&nbsp;</td>");
            }
            sb.append("</tr>");
        }
        sb.append("</table>");
        sb.append("<div class='footer'>Generated: ")
          .append(java.time.LocalDate.now())
          .append(" | System-generated document</div></body></html>");
        return sb.toString();
    }

    private void appendRow(StringBuilder sb, String label, String value) {
        sb.append("<tr><td class='label'>").append(label)
          .append(":</td><td>").append(value).append("</td></tr>");
    }
}
