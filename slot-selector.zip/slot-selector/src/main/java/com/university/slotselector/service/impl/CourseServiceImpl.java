package com.university.slotselector.service.impl;

import com.university.slotselector.dto.request.CreateCourseRequest;
import com.university.slotselector.dto.response.CourseResponse;
import com.university.slotselector.entity.Course;
import com.university.slotselector.entity.DegreeCourseMapping;
import com.university.slotselector.exception.BusinessRuleException;
import com.university.slotselector.exception.ResourceNotFoundException;
import com.university.slotselector.repository.CourseRepository;
import com.university.slotselector.service.CourseService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class CourseServiceImpl implements CourseService {

    private final CourseRepository courseRepository;

    @Override
    @Transactional
    public CourseResponse create(CreateCourseRequest request) {
        if (courseRepository.existsByCourseCode(request.getCourseCode())) {
            throw new BusinessRuleException(
                "Course with code '" + request.getCourseCode() + "' already exists. " +
                "Use AddCourseToDegree to link it to another degree.");
        }
        Course course = Course.builder()
                .name(request.getName())
                .courseCode(request.getCourseCode().toUpperCase())
                .creditHours(request.getCreditHours())
                .description(request.getDescription())
                .build();
        Course saved = courseRepository.save(course);
        log.info("Course created: {} ({})", saved.getName(), saved.getCourseCode());
        return toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public CourseResponse getById(Long id) {
        return toResponse(findById(id));
    }

    @Override
    @Transactional(readOnly = true)
    public CourseResponse getByCode(String courseCode) {
        Course course = courseRepository.findByCourseCode(courseCode.toUpperCase())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Course", "courseCode", courseCode));
        return toResponse(course);
    }

    @Override
    @Transactional(readOnly = true)
    public List<CourseResponse> getAll() {
        return courseRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<CourseResponse> getCoursesForStudentSemester(Long degreeId, Integer semester) {
        /*
         * Returns all courses assigned to this degree at this semester.
         * Includes courses shared from other departments
         * (identified by same courseCode in different degree mappings).
         */
        return courseRepository.findByDegreeAndSemester(degreeId, semester)
                .stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<CourseResponse> searchByName(String name) {
        return courseRepository.findByNameContainingIgnoreCase(name)
                .stream().map(this::toResponse).toList();
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private Course findById(Long id) {
        return courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course", "id", id));
    }

    private CourseResponse toResponse(Course c) {
        // Collect names of degrees that offer this course
        List<String> degrees = c.getDegreeMappings().stream()
                .map(m -> m.getDegree().getCode() + " (Sem " + m.getSemesterNumber() + ")")
                .toList();

        // Count slots that still have available capacity
        long slotGroupCount = c.getLectureSlots().stream()
                .filter(ls -> ls.hasAvailableSeats())
                .count();

        return CourseResponse.builder()
                .id(c.getId())
                .name(c.getName())
                .courseCode(c.getCourseCode())
                .creditHours(c.getCreditHours())
                .description(c.getDescription())
                .availableSlotGroups((int) slotGroupCount)
                .offeredInDegrees(degrees)
                .build();
    }

    @Override
    @Transactional
    public void delete(Long id) {
        Course course = courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course", "id", id));
        if (!course.getLectureSlots().isEmpty()) {
            throw new BusinessRuleException(
                "Cannot delete course '" + course.getName() + "': it has " +
                course.getLectureSlots().size() + " active slot(s). Delete the slots first.");
        }
        courseRepository.delete(course);
        log.info("Course {} ({}) deleted", course.getName(), course.getCourseCode());
    }

    // edit: new update method — allows admin to change course name, code, credits and description
    @Override
    @Transactional
    public CourseResponse update(Long id, CreateCourseRequest request) {
        // edit: find existing course or 404
        Course course = courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course", "id", id));
        // edit: check code uniqueness only if it changed
        if (!course.getCourseCode().equalsIgnoreCase(request.getCourseCode())) {
            courseRepository.findByCourseCode(request.getCourseCode()).ifPresent(existing -> {
                throw new BusinessRuleException(
                    "Course code '" + request.getCourseCode() + "' is already used by another course.");
            });
        }
        // edit: apply updated values
        course.setName(request.getName().trim());
        course.setCourseCode(request.getCourseCode().toUpperCase().trim());
        course.setCreditHours(request.getCreditHours());
        course.setDescription(request.getDescription());
        course = courseRepository.save(course); // edit: persist
        log.info("Course {} ({}) updated", course.getName(), course.getCourseCode()); // edit: audit
        return toResponse(course); // edit: return updated DTO
    }
}
