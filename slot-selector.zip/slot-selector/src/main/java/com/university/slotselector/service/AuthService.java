package com.university.slotselector.service;

import com.university.slotselector.dto.request.LoginRequest;
import com.university.slotselector.dto.response.AuthResponse;

/**
 * AuthService — contract for authentication operations.
 * Only login is needed since admin creates accounts (no self-registration).
 */
public interface AuthService {
    AuthResponse login(LoginRequest request);
}
