package com.university.slotselector.enums;

/**
 * Status of an individual payment transaction.
 */
public enum PaymentStatus {
    SUCCESS,
    FAILED,
    PENDING
}
