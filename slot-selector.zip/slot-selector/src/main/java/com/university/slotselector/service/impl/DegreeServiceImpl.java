package com.university.slotselector.service.impl;

import com.university.slotselector.dto.request.AddCourseToDegreeRequest;
import com.university.slotselector.dto.request.CreateDegreeRequest;
import com.university.slotselector.dto.response.CourseResponse;
import com.university.slotselector.dto.response.DegreeResponse;
import com.university.slotselector.dto.response.SemesterCoursesResponse;
import com.university.slotselector.entity.*;
import com.university.slotselector.exception.BusinessRuleException;
import com.university.slotselector.exception.ResourceNotFoundException;
import com.university.slotselector.repository.*;
import com.university.slotselector.service.DegreeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class DegreeServiceImpl implements DegreeService {

    private final DegreeRepository degreeRepository;
    private final DepartmentRepository departmentRepository;
    private final CourseRepository courseRepository;
    private final DegreeCourseMappingRepository dcmRepository;
    private final StudentRepository studentRepository;

    @Override
    @Transactional
    public DegreeResponse create(CreateDegreeRequest request) {
        Department department = departmentRepository.findById(request.getDepartmentId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Department", "id", request.getDepartmentId()));

        if (degreeRepository.existsByCodeAndDepartmentId(
                request.getCode(), request.getDepartmentId())) {
            throw new BusinessRuleException(
                    "Degree with code '" + request.getCode() +
                            "' already exists in department '" + department.getName() + "'.");
        }

        Degree degree = Degree.builder()
                .name(request.getName())
                .code(request.getCode().toUpperCase())
                .durationYears(request.getDurationYears())
                .department(department)
                .build();

        Degree saved = degreeRepository.save(degree);
        log.info("Degree created: {} under {}", saved.getName(), department.getName());
        return toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public DegreeResponse getById(Long id) {
        Degree degree = degreeRepository.findByIdWithCourseMappings(id)
                .orElseThrow(() -> new ResourceNotFoundException("Degree", "id", id));
        return toResponse(degree);
    }

    @Override
    @Transactional(readOnly = true)
    public List<DegreeResponse> getByDepartment(Long departmentId) {
        return degreeRepository.findByDepartmentId(departmentId)
                .stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional
    public void addCourseToDegree(AddCourseToDegreeRequest request) {
        Degree degree = degreeRepository.findById(request.getDegreeId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Degree", "id", request.getDegreeId()));

        Course course = courseRepository.findById(request.getCourseId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Course", "id", request.getCourseId()));

        // Validate semester number is within degree bounds
        int maxSemester = degree.getDurationYears() * 2;
        if (request.getSemesterNumber() > maxSemester) {
            throw new BusinessRuleException(
                    "Semester " + request.getSemesterNumber() +
                            " exceeds the maximum semester (" + maxSemester +
                            ") for a " + degree.getDurationYears() + "-year degree.");
        }

        // Prevent duplicate mapping
        if (dcmRepository.existsByDegreeIdAndCourseIdAndSemesterNumber(
                degree.getId(), course.getId(), request.getSemesterNumber())) {
            throw new BusinessRuleException(
                    "Course '" + course.getCourseCode() +
                            "' is already mapped to degree '" + degree.getCode() +
                            "' at semester " + request.getSemesterNumber() + ".");
        }

        DegreeCourseMapping mapping = DegreeCourseMapping.builder()
                .degree(degree)
                .course(course)
                .semesterNumber(request.getSemesterNumber())
                .isCompulsory(request.getIsCompulsory())
                .build();

        dcmRepository.save(mapping);
        log.info("Course {} added to degree {} at semester {}",
                course.getCourseCode(), degree.getCode(), request.getSemesterNumber());
    }

    @Override
    @Transactional
    public void removeCourseFromDegree(Long degreeId, Long courseId) {
        DegreeCourseMapping mapping = dcmRepository
                .findByDegreeIdAndCourseId(degreeId, courseId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "DegreeCourseMapping", "degreeId+courseId",
                        degreeId + "+" + courseId));
        dcmRepository.delete(mapping);
    }

    // ── Private helpers ───────────────────────────────────────────────────

    private DegreeResponse toResponse(Degree degree) {
        // Group course mappings by semester number
        Map<Integer, List<DegreeCourseMapping>> bySemester = degree.getCourseMappings()
                .stream()
                .collect(Collectors.groupingBy(DegreeCourseMapping::getSemesterNumber));

        List<SemesterCoursesResponse> semesters = new ArrayList<>();
        bySemester.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .forEach(entry -> {
                    List<CourseResponse> courses = entry.getValue().stream()
                            .map(m -> CourseResponse.builder()
                                    .id(m.getCourse().getId())
                                    .name(m.getCourse().getName())
                                    .courseCode(m.getCourse().getCourseCode())
                                    .creditHours(m.getCourse().getCreditHours())
                                    .description(m.getCourse().getDescription())
                                    .availableSlotGroups(0) // populated on detailed views
                                    .offeredInDegrees(List.of())
                                    .build())
                            .toList();
                    semesters.add(SemesterCoursesResponse.builder()
                            .semesterNumber(entry.getKey())
                            .courses(courses)
                            .build());
                });

        return DegreeResponse.builder()
                .id(degree.getId())
                .name(degree.getName())
                .code(degree.getCode())
                .durationYears(degree.getDurationYears())
                .departmentName(degree.getDepartment().getName())
                .departmentCode(degree.getDepartment().getCode())
                .semesters(semesters)
                .build();
    }

    @Override
    @Transactional
    public void delete(Long id) {
        Degree degree = degreeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Degree", "id", id));
        // Guard: block delete if students are enrolled in this degree
        long studentCount = studentRepository.countByDegreeId(id);
        if (studentCount > 0) {
            throw new BusinessRuleException(
                    "Cannot delete degree '" + degree.getName() + "': " +
                            studentCount + " student(s) are enrolled. Reassign or remove students first.");
        }
        degreeRepository.delete(degree);
        log.info("Degree {} ({}) deleted", degree.getName(), degree.getCode());
    }


    // edit: new update method — allows admin to rename a degree or change its duration
    @Override
    @Transactional
    public DegreeResponse update(Long id, CreateDegreeRequest request) {
        // edit: look up existing degree or throw 404
        Degree degree = degreeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Degree", "id", id));
        // edit: apply new values (department cannot be changed via this endpoint)
        degree.setName(request.getName().trim());
        degree.setCode(request.getCode().toUpperCase().trim());
        degree.setDurationYears(request.getDurationYears());
        degree = degreeRepository.save(degree); // edit: persist changes
        log.info("Degree {} ({}) updated", degree.getName(), degree.getCode()); // edit: audit log
        return toResponse(degree); // edit: return updated DTO
    }

}