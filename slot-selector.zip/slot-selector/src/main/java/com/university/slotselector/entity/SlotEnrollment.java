package com.university.slotselector.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

/**
 * ============================================================
 * SlotEnrollment  (maps to table: slot_enrollments)
 * ============================================================
 * Records that a specific Student has enrolled in a specific
 * LectureSlot. ONE record per (student, slot) — not per day.
 *
 * When a student enrols in "OOP Slot 2" they get ONE row here,
 * and their timetable is built by reading
 *   enrollment.lectureSlot.lectures  (the List<SlotLecture>)
 * ============================================================
 */
@Entity
@Table(name = "slot_enrollments",
       uniqueConstraints = @UniqueConstraint(
               columnNames = {"student_id", "slot_group_code"}))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SlotEnrollment extends BaseEntity {

    /** The student who enrolled. */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    /**
     * The slot (e.g., "OOP Slot 2") the student chose.
     * Loaded eagerly so the timetable can be built without
     * extra queries.
     */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "lecture_slot_id", nullable = false)
    private LectureSlot lectureSlot;

    /**
     * Denormalised from lectureSlot for the unique constraint
     * and for quick drop lookups.
     */
    @Column(name = "slot_group_code", nullable = false, length = 80)
    private String slotGroupCode;

    @Column(name = "enrolled_at", nullable = false)
    @Builder.Default
    private LocalDateTime enrolledAt = LocalDateTime.now();

    @Column(name = "is_dropped", nullable = false)
    @Builder.Default
    private boolean dropped = false;

    @Column(name = "dropped_at")
    private LocalDateTime droppedAt;
}
