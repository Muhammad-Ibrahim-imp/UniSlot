# University Slot Selection System — Backend

> **Database:** MySQL 8.x &nbsp;|&nbsp; **Framework:** Spring Boot 4.0.5 &nbsp;|&nbsp; **Java:** 21

A REST API that lets students choose their own lecture slots and professors. Admins configure the full academic hierarchy; students browse available slots after fee payment; the finance team manages invoices and transactions.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Language | Java 21 (LTS) |
| Framework | Spring Boot **4.0.5** |
| Build | Gradle **Kotlin DSL** |
| Database | MySQL 8.x |
| ORM | Spring Data JPA + Hibernate 7 |
| Security | Spring Security 7 + JWT (jjwt 0.12.6) |
| PDF | iText 7 (community 8.0.4) |
| API Docs | SpringDoc OpenAPI 2.8.5 (Swagger UI) |
| Testing | JUnit 5 + Spring Boot Test + H2 (in-memory) |

---

## Quick Start

### Prerequisites
- Java 21 JDK
- MySQL 8.x running on port 3306
- Database created: `CREATE DATABASE slot_selector_db;`

### Configure (env vars or application.yml)
```bash
export DB_USERNAME=root
export DB_PASSWORD=yourpassword
export JWT_SECRET=YourVeryStrongSecretKeyHere
export PDF_OUTPUT_DIR=./generated-pdfs   # optional, defaults to ./generated-pdfs
```

### Run
```bash
./gradlew bootRun
```

### Swagger UI
```
http://localhost:8080/swagger-ui.html
```

---

## Default Admin Account *(created automatically on first startup)*

| Field | Value |
|---|---|
| Email | admin@university.edu |
| Password | admin123 |

> ⚠️ Change this password immediately before going to production.

---

## Database Schema — Key Design Decisions

### Specialization hierarchy (EERD)
| Superclass | Subclasses | Type |
|---|---|---|
| `users` | admin_user / student / finance_user | Partial, overlapping — stored as `role` enum in `users` table |
| `degree_programs` | `degree_years` (Year 1–4) | Total, disjoint — separate `degree_years` rows |
| `courses` | theory_course / lab_course | Partial, disjoint — `is_lab` flag + optional lab fields |
| `professors` | full_time / visiting | Partial, disjoint — `professor_type` enum + nullable extra fields |

### All tables
| Table | Type | Purpose |
|---|---|---|
| `users` | Strong | Login accounts for all roles |
| `departments` | Strong | University departments |
| `degree_programs` | Strong | Degree offerings per department |
| `degree_years` | Strong | Each year of a degree (Year 1, 2, 3, 4) |
| `degree_year_sections` | Weak | Section A/B/C within a degree year |
| `degree_year_courses` | Weak (bridge) | Course-to-year mapping with semester number |
| `courses` | Strong | Global course catalogue |
| `professors` | Strong | Faculty with evaluation analytics |
| `lecture_slots` | Weak | One row per day of a weekly slot |
| `fee_structures` | Strong | Tuition/exam/lab fee per degree per year |
| `payment_invoices` | Weak | Per-student billing records |
| `payment_transactions` | Weak | Individual cash/bank/online payments |
| `slot_enrollments` | Weak | Student ↔ slot selection records |
| `selection_windows` | Strong | Admin-controlled slot selection open/close windows |
| `timetable_pdfs` | Weak | Audit trail of generated PDFs |
| `notifications` | Weak | Fee/slot/PDF alerts per user |
| `audit_logs` | Weak | Every admin action logged |

---

## API Workflow

### Admin setup flow
```
POST /api/auth/login                          → JWT token
POST /api/admin/departments                   → Create departments
POST /api/admin/degrees                       → Create degree programs
POST /api/admin/degrees/{id}/years            → Create degree years (Year 1–4)
POST /api/admin/degrees/years/{id}/sections   → Create sections (A, B, C)
POST /api/admin/courses                       → Create courses
POST /api/admin/degrees/add-course            → Assign course to a degree year + semester
POST /api/admin/professors                    → Register professors
POST /api/admin/slots                         → Create lecture slots
POST /api/admin/students                      → Register students (auto-creates login)
PATCH /api/admin/students/fee-status          → Mark fee PAID → unlocks slot selection
POST /api/admin/selection-windows             → Open slot selection for a degree year
```

### Student flow
```
POST /api/auth/login                          → JWT token
GET  /api/students/me/profile                 → Own profile
GET  /api/students/me/courses                 → Courses for my degree year + semester
GET  /api/students/me/courses/{id}/available-slots → Available slots for a course
POST /api/students/me/enrollments             → Select a slot (fee must be PAID)
GET  /api/students/me/enrollments             → View current timetable
DELETE /api/students/me/enrollments/{code}    → Drop a slot
GET  /api/students/me/timetable/pdf           → Download weekly schedule as PDF
```

### Finance flow
```
GET  /api/finance/invoices/unpaid             → All unpaid student invoices
POST /api/finance/payments                    → Record a payment transaction
GET  /api/finance/dashboard                   → Summary: collected, outstanding, queue
```

---

## Business Rules

| Rule | Description |
|---|---|
| Fee gate | Students cannot select slots until `fee_status = PAID` |
| Capacity | `enrolled_count < max_capacity` enforced atomically |
| No duplicate course | One slot per course per student |
| No time clash | New slot checked against student's existing timetable |
| Priority queue | Students who paid earlier (`fee_paid_at` ASC) register first |
| Cross-dept courses | Same `course_code` can appear in multiple degree years at different semesters |
| Slot fill analytics | `slot_filled_at − slot_opened_at` = professor popularity metric |

---

## Spring Boot 4.x Notes

Spring Boot 4.0.5 upgrades over 3.x:
- Requires **Java 21** minimum (virtual threads supported via `spring.threads.virtual.enabled=true`)
- Ships with **Hibernate 7** and **Jakarta EE 11**
- Uses **Spring Framework 7**
- `spring-security` package updated to 7.x API
- `SpringDocOpenAPI 2.8.5` required (2.6.x incompatible with Spring Boot 4)
- Dependency Management plugin bumped to `1.1.7`

---

## Project Structure

```
src/main/java/com/university/slotselector/
├── config/          SecurityConfig, OpenApiConfig, AppConfig, DataInitializer
├── controller/      Auth, Admin (Dept/Degree/Course/Prof/Slot/Student), Student, Finance
├── dto/
│   ├── request/     CreateDepartmentRequest, CreateStudentRequest, SelectSlotRequest...
│   └── response/    ApiResponse<T>, StudentResponse, LectureSlotResponse...
├── entity/          User, Department, DegreeProgram, DegreeYear, Section, Course,
│                    Professor, LectureSlot, FeeStructure, PaymentInvoice,
│                    PaymentTransaction, SlotEnrollment, TimetablePdf,
│                    Notification, AuditLog, SelectionWindow
├── enums/           Role, FeeStatus, LectureDay, PaymentMethod, PaymentStatus
├── exception/       ResourceNotFoundException, BusinessRuleException, GlobalExceptionHandler
├── repository/      One JpaRepository per entity
├── security/        JwtTokenProvider, JwtAuthenticationFilter, UserDetailsServiceImpl
└── service/
    ├── (interfaces) AuthService, StudentService, SlotEnrollmentService...
    └── impl/        AuthServiceImpl, StudentServiceImpl, PdfGenerationServiceImpl...
```
