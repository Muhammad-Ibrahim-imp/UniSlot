rootProject.name = "slot-selector"
